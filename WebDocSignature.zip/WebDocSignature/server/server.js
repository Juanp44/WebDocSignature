const express = require('express')
const hbs = require('express-handlebars')
const path = require('path')
const https = require('https')
const fs = require('fs')
const bodyParser = require("body-parser");
const uploadRouter = require('../routes/uploads')
const loginRouter = require('../routes/login')
const app = express()
const port = 8080;

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.engine('hbs', hbs({
    extname: 'hbs',
    defaultLayout: 'layout',
    layoutsDir: path.join(__dirname, '../views/layouts/')
}));
app.set('view engine', 'hbs');
app.use(express.static(path.join(__dirname, '../public')))
app.route('/')
    .get((req, res) => {
        res.render('login', {
            title: 'Login',
            condition: false
        })
    })

app.use(loginRouter); 
app.use(uploadRouter); 

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"; 
const httpsServer = https.createServer({
    key: fs.readFileSync('localhost-key.pem'),
    cert: fs.readFileSync('localhost.pem')
}, app);

httpsServer.listen(port, () => {
    console.log("HTTPS server running on port 8080");
})
const router = require('express').Router()
let credencialesBD = require('../credencialesBD.json')
let dialog = require('dialog')

router.route('/envioCredenciales')
  .post((req, res) => {
    let {
      email,
      password
    } = req.body;
    if (credencialesBD.find(c => c.correo == email && c.password == password)) {
      res.render('home');
    } else {
      dialog.err("Usuario o contraseña no válidos", "Login incorrecto");
      res.render('login');
    }
  })


module.exports = router;
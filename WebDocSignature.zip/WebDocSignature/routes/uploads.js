const router = require('express').Router()
const multer = require('multer')
const path = require('path')
const globby = require('globby')
const fs = require('fs')
const axios = require('axios')

let fileNameToUpload = '';
const storage = multer.diskStorage({
    destination: path.join(__dirname, '../public/files'),
    filename: (req, file, cb) => {
        cb(null, file.originalname); 
    }
})

const fileFilter = (req, file, cb) => {
    fileNameToUpload = file.originalname; 
    if (file.mimetype === 'text/plain') {
        cb(null, true);
    } else {
        cb(null, false); 
    }
}

const uploadFile = multer({
    storage,
    limits: {
        fileSize: 1000000
    },
    fileFilter
})

router.get('/upload', async (req, res) => {
    const paths = await globby(['**/public/files/*']);
    const pathsNew = paths.map(function (x) {
        return x.replace("public/files/", '')
    })
    res.send(pathsNew)
})

router.post('/upload', uploadFile.single('fileToUpload'), async (req, res) => {
    res.redirect(303, '/archivoCertificado'); 
});


router.get('/archivoCertificado', (req, res) => {

    let rutaArchivo = '../public/files/' + fileNameToUpload
    const filePath = path.join(__dirname, rutaArchivo);

    try {
        if (fs.statSync(filePath).isFile()) {
            res.download(filePath)
        }
    } catch (e) {
        console.log("Archivo no existente")
    }
})

router.post('/archivosSubidos', (req, res) => {

    let archivosArreglo;
    axios('https://localhost:8080/upload') 
        .then(response => {
            archivosArreglo = response.data.map(archivo => {
                return {
                    nombre: archivo
                }
            })

            res.render('home', {
                title: "Home",
                condition: false,
                pathsNew: archivosArreglo
            })

        })
});

module.exports = router;